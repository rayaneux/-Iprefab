AOS.init();

function filterProduct(value) {
    //Button class code
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
    //check if value equals innerText
    if (value.toUpperCase() == button.innerText.toUpperCase()) {
        button.classList.add("active");
    } else {
        button.classList.remove("active");
    }
    });
    //on sélectionne toute les cases
    let cases = document.querySelectorAll(".case");
    //on boucle pour toute les carte
    cases.forEach((element) => {
    //affachage de toutes les carte sur l'appuie du bouton 'all'
        if (value === 'Tout afficher') {
            element.classList.remove("hide");
        } else {
            //Vérification si element contient la catégorie de la classe
            if (element.classList.contains(value)) {
            //afficher l'élément basé sur la catégorie
            element.classList.remove("hide");
            } else {
            //cacher les autres éléments
            element.classList.add("hide");
            }
        }
    });
}

$(document).ready(function() {
    // alert("jQuery");
    // alert($().SPServices.SPGetCurrentSite());
    // console.log("Hello world");

    // Définit les paramètres pour la fonction GetListItems
    var listName = "PMList";
    var viewName = "";
    var CAMLQuery = "<Query><OrderBy><FieldRef Name='Title' /></OrderBy></Query>";

    var CAMLViewFields = "<ViewFields>"
                            + "<FieldRef Name='Titre' />"
                            + "<FieldRef Name='Description' />"
                            + "<FieldRef Name='Auteur' />"
                            + "<FieldRef Name='Perimetre' />"
                            + "<FieldRef Name='Illustration' />"
                            + "<FieldRef Name='LienTuto' />"
                        + "</ViewFields>";
    var CAMLRowLimit = 0;

    // Appelle la fonction GetListItems pour récupérer les éléments de la liste SharePoint
    $().SPServices({
        operation: "GetListItems",
        listName: listName,
        viewName: viewName,
        CAMLQuery: CAMLQuery,
        CAMLViewFields: CAMLViewFields,
        CAMLRowLimit: CAMLRowLimit,
        completefunc: function(xData, Status) {
            let allTags = [];
            const mySet = new Set();
            // Traite les données récupérées et les insère dans le tableau HTML
            var table = $("#tool_container");
            var tags = $("#buttons");
            $(xData.responseXML).SPFilterNode("z:row").each(function() {
                var title = $(this).attr("ows_Title");
                var description = $(this).attr("ows_Description");
                var surname = $(this).attr("ows_Auteur");
                var profession = $(this).attr("ows_Perimetre");
                var picture = $(this).attr("ows_Illustration");
                var link = $(this).attr("ows_LienTuto");
                
                JobAndColor = profession.split(" ");
                job = JobAndColor[0];
                color = JobAndColor[1];
                allTags.push(job);

                var row = "<div class='case " + job + "'style='border-bottom: 15px solid " + color + "; border-top: 15px solid " + color + ";'>"
                            + "<div class='tool_content'>"
                                + "<div class='tool_illustration'>"
                                     + "<figure class='snip1576 job'>"
                                        + "<img src=" + picture + " alt='illustration' />"
                                        + "<figcaption>"
                                        + "<h3> AUTEUR <span>" + surname + "</span></h3>"
                                        + "</figcaption>"
                                        + "<a href=" + link + " target='_blank'></a>"
                                    + "</figure>"
                                + "</div>"
                                + "<div class='tool_description'>"
                                    + "<h3 class='tool-name'>" + title + "</h3>"
                                    + "<p><br>" + description + "</p>"
                                + "</div>"
                            + "</div>"
                        + "</div>"

                table.append(row);
            });

            allTags.forEach(element => {
                    mySet.add(element);
                });
            mySet.forEach(element => {
                var tag = "<a class='button-value " + element + "' onclick=\"filterProduct('" + element + "')\">" + element + "</a>";
                tags.append(tag);
            });
        }
    });

    searchBtn = document.querySelector("#search");
    searchBar = document.querySelector("#searchbar");


    searchBar.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
            let searchedLetters = document.getElementById("searchbar").value;
            const cases = document.querySelectorAll(".case");
            filterElements(searchedLetters, cases);
        }
    });

    searchBtn.addEventListener("click", () =>{
        let searchedLetters = document.getElementById("searchbar").value;
        const cases = document.querySelectorAll(".case");
        filterElements(searchedLetters, cases);
    });

    function filterElements(letters, elements) {
        if(letters === ""){
            filterProduct("Tout afficher");
        }
        for (let i=0; i<elements.length; i++){
            if(elements[i].textContent.toLowerCase().includes(letters) && !(elements[i].classList.contains("hide"))){
                elements[i].classList.remove("hide");
            } else {
                elements[i].classList.add("hide");
            }
        }
    }
});