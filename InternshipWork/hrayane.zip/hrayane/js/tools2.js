/* AOS.init();
This initializes the AOS library to apply animations when elements come into the viewport during scrolling.
AOS is used to add visual effects to the page elements. */

AOS.init();

/** filterProduct(value):

This function is called when the user clicks on one of the buttons corresponding to a specific category (job) of tools.
It takes the value of the button (category) as input and filters the tools accordingly.
It adds the "active" class to the clicked button and removes it from other buttons to indicate the active category.
It hides or shows the tool elements based on whether they belong to the selected category or not.
The function also handles a special case when the value is "Tout afficher" (meaning "Show all" in French) to display all tools.
 */

function filterProduct(value) {
    //Button class code
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
    //vérifie si value est égale à innerText
    if (value.toUpperCase() == button.innerText.toUpperCase()) {
        button.classList.add("active");
    } else {
        button.classList.remove("active");
    }
    });
    //on sélectionne toute les cases
    let cases = document.querySelectorAll(".case");
    //on boucle pour toutes les cartes
    cases.forEach((element) => {
    //affichage de toutes les carte sur l'appuie du bouton 'all'
        if (value === 'Tout afficher') {
            element.classList.remove("hide");
        } else {
            //Vérification si element contient la catégorie de la classe
            if (element.classList.contains(value)) {
            //afficher l'élément basé sur la catégorie
            element.classList.remove("hide");
            } else {
            //cacher les autres éléments
            element.classList.add("hide");
            }
        }
    });
}

$(document).ready(function() {
    // Alertes pour vérifier si les biliothèques ont bien été importées

    // alert("jQuery");
    // alert($().SPServices.SPGetCurrentSite());

    // Définit les paramètres pour la fonction GetListItems

    let listName = "ToolsList";  // Nom de la liste des éléments à récupérer
    let viewName = "";  
    let CAMLQuery = "<Query><OrderBy><FieldRef Name='Title' /></OrderBy></Query>";  // Requête CAML pour trier par ordre alphabétique selon le Titre

    // Définition des colonnes de la liste (pour les identifier par la suite)
    let CAMLViewFields = "<ViewFields>"
                            + "<FieldRef Name='Titre' />"
                            + "<FieldRef Name='Description' />"
                            + "<FieldRef Name='Metier' />"
                            + "<FieldRef Name='Garant' />"
                            + "<FieldRef Name='Illustration' />"
                            + "<FieldRef Name='Logo' />"
                            + "<FieldRef Name='LienDuSite' />"
                            + "<FieldRef Name='FollowUp' />"
                        + "</ViewFields>";
    
    let CAMLRowLimit = 0; // Initialisation de la limite à 0 afin d'afficher l'intégralité des éléments

    // Appelle la fonction GetListItems pour récupérer les éléments de la liste SharePoint
    $().SPServices({
        operation: "GetListItems",
        listName: listName,
        viewName: viewName,
        CAMLQuery: CAMLQuery,
        CAMLViewFields: CAMLViewFields,
        CAMLRowLimit: CAMLRowLimit,
        completefunc: function(xData, Status) {
            let allTags = [];  // Initialisation d'une liste pour stocker les catégories de métier
            const mySet = new Set(); // Initialisation d'un set pour enlever les doublons dans la liste des catégories

            // Traite les données récupérées et les insère dans le tableau HTML
            let table = $("#tool_container"); // Déclaration contenant la div contenant la collection d'outils
            let tags = $("#buttons");  // Déclaration contenant la div contenant la liste des catégories de métier

            // Itération pour chaque outil trouvé dans la liste SharePoint
            $(xData.responseXML).SPFilterNode("z:row").each(function() {
                // Déclarations de variables conetnant les données d'un élément de la liste SharePoint
                let title = $(this).attr("ows_Title");  // Varibale contenant le titre de l'outil
                let description = $(this).attr("ows_Description");  // Varibale contenant la description de l'outil
                let profession = $(this).attr("ows_Metier");  // Varibale contenant le métier et la couleur de l'outil
                let surname = $(this).attr("ows_Garant");  // Varibale contenant le nom du Garant de l'outil
                let picture = $(this).attr("ows_Illustration");  // Varibale contenant l'image d'illustration de l'outil
                let logo = $(this).attr("ows_Logo");  // Varibale contenant le logo de l'outil
                let link = $(this).attr("ows_LienDuSite");  // Varibale contenant le lien du site à pointer
                let followup = $(this).attr("ows_FollowUp");  // Varibale contenant le lien du site followup de l'outil
                
                // Séparation du métier et de la couleur du métier dans la liste "JobAndColor"
                JobAndColor = profession.split(" ");
                job = JobAndColor[0];
                color = JobAndColor[1];
                allTags.push(job);  // Ajout du métier dans la liste "allTags"
                
                // Variable row contenant le code html nécessaire pour générer les informations d'un outil avec une mise en forme spécifique
                let row = "<div class='case " + job + "'style='border-bottom: 15px solid " + color + "; border-top: 15px solid " + color + ";'>"
                            + "<div class='tool_content'>"
                                + "<div class='tool_illustration'>"
                                     + "<figure class='snip1576 job'>"
                                        + "<img src=" + picture + " alt='illustration' />"
                                        + "<figcaption>"
                                        + "<h3> GARANT <span>" + surname + "</span></h3>"
                                        + "</figcaption>"
                                        + "<a href=" + link + " target='_blank'></a>"
                                    + "</figure>"
                                + "</div>"
                                + "<div class='tool_description'>"
                                    + "<h3 class='tool-name'>" + title + "</h3>"
                                    + "<p><br>" + description + "</p>"
                                + "</div>"
                            + "</div>"
                            + "<div class='logos'>"
                                + "<div class='tool_logo'>"
                                    + "<img src='" + logo + "' alt='logo'>"
                                + "</div>"
                                + "<div class='tool_logo followup_logo'>"
                                    + "<a href=" + followup + " target='_blank'><img src='https://inshare.grp.collab.group.safran/team/TESTSP/PictureLibrary/FUP_96.png' alt='followup'></a>"
                                + "</div>"
                            + "</div>"
                        + "</div>"

                table.append(row);  // Ajout de l'outil dans la div contenant la collection d'outils

                // répétition de la boucle jusqu'à parcourir toutes la liste SharePoint (pour afficher tous les outils)
            });

            // Stockage des catégories de métier dans le set "mySet" pour elever tous les doublons
            allTags.forEach(element => {  // Parcours de la liste contenant les catégories
                    mySet.add(element);  // Ajout d'un élément non répété dans "mySet"
                });
            // Parcours les catégories de métier afin de les afficher
            mySet.forEach(element => {
                // Variable tag contenant le code html nécessaire pour générer les boutons pour les métiers
                let tag = "<a class='button-value " + element + "' onclick=\"filterProduct('" + element + "')\">" + element + "</a>";
                tags.append(tag); // Ajout du code html générer dans "tag" à tags, le div contenant toutes les catégories de métiers
            });
        }
    });

    searchBtn = document.querySelector("#search");  // Bouton rechercher
    searchBar = document.querySelector("#searchbar");  // Barre de recherche

    // Filtrage par mots clés de l'utilisateur en appuyant sur la touche "Entrée" du clavier
    searchBar.addEventListener('keydown', function(event) {  // Capte un évenement quand une touche est appuyée
        if (event.key === 'Enter') {  //  Si la touche correspond à la touche "Entrée"
            let searchedLetters = document.getElementById("searchbar").value;  // Contenu de la barre de recherche (saisie utilisateur)
            const cases = document.querySelectorAll(".case");  // Éléments/Outils à afficher
            filterElements(searchedLetters, cases);  // Execution de la fonction de filtrage
        }
    });

    // Filtrage par mots clés de l'utilisateur en appuyant sur la touche "Rechercher" du site
    searchBtn.addEventListener("click", () =>{  // Capte un évenement quand le bouton "Rechercher" est appuyé
        let searchedLetters = document.getElementById("searchbar").value;  // Contenu de la barre de recherche (saisie utilisateur)
        const cases = document.querySelectorAll(".case");  // Éléments/Outils à afficher
        filterElements(searchedLetters, cases);  // Execution de la fonction de filtrage
    });

    // Filtrage en fonction de la chaine de caractère insérée dans la barre de recherche par l'utilisateur
    // La fonction prend en paramètre le contenu de la barre de recherche et les élements à afficher/masquer
    function filterElements(letters, elements) {
        if(letters === ""){  // Si la saisie utilisateur est vide
            filterProduct("Tout afficher");  // Afficher tous les élements
        }
        for (let i=0; i<elements.length; i++){
            // Si le contenu de la barre de recherche et parmi les éléments affiché
            if(elements[i].textContent.toLowerCase().includes(letters) && !(elements[i].classList.contains("hide"))){
                elements[i].classList.remove("hide");  // Afficher l'élement en enlevant la classe "hide"
            } else {
                elements[i].classList.add("hide"); // Masquer l'élement en ajoutant la classe "hide"
            }
        }
    }
});