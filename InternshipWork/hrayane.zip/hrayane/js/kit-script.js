AOS.init();

$(document).ready(function() {
    // alert("jQuery");
    // alert($().SPServices.SPGetCurrentSite());
    // console.log("Hello world");

    // Définit les paramètres pour la fonction GetListItems
    var listName = "KitList";
    var viewName = "";
    var CAMLQuery = "<Query><OrderBy><FieldRef Name='Position' /></OrderBy></Query>";

    var CAMLViewFields = "<ViewFields>"
                            + "<FieldRef Name='Titre' />"
                            + "<FieldRef Name='Description' />"
                            + "<FieldRef Name='Image' />"
                            + "<FieldRef Name='URL' />"
                            + "<FieldRef Name='Position' />"
                        + "</ViewFields>";
    var CAMLRowLimit = 0;

    // Appelle la fonction GetListItems pour récupérer les éléments de la liste SharePoint
    $().SPServices({
        operation: "GetListItems",
        listName: listName,
        viewName: viewName,
        CAMLQuery: CAMLQuery,
        CAMLViewFields: CAMLViewFields,
        CAMLRowLimit: CAMLRowLimit,
        completefunc: function(xData, Status) {
            // Traite les données récupérées et les insère dans le tableau HTML
            var steps = $("#steps-container");
            $(xData.responseXML).SPFilterNode("z:row").each(function() {
                let title = $(this).attr("ows_Title");
                let description = $(this).attr("ows_Description");
                let image = $(this).attr("ows_Image");
                let url = $(this).attr("ows_URL");
                let position = $(this).attr("ows_Position");

                let r = 0;
                let posNumber = Math.floor(position); // arrondi le nombre à l'unité en dessous
                r = posNumber % 2;

                if(r === 0){
                    let row = "<div class='arrow'>"
                                + "<div class='line'></div>"
                                + "<div class='spike'></div>"
                            + "</div>"
                            + "<div class='step step-reverse'>"
                                + "<h2>" + posNumber + "</h2>"
                                + "<a href='" + url + "' class='step-link' target='_blank'>"
                                    + "<div class='step-circle'>"
                                        + "<img src='" + image +"'>"
                                    + "</div>"
                                + "</a>"
                                + "<div class='step-txt step-txt-reverse'>"
                                    + "<h3>" + title + "</h3>"
                                    + "<p>" + description + "</p>"
                                + "</div>"
                            + "</div>";
                    steps.append(row);
                } else {
                    let row = "<div class='arrow'>"
                                + "<div class='line'></div>"
                                + "<div class='spike'></div>"
                            + "</div>"
                            + "<div class='step " + posNumber +"'>"
                                + "<h2>" + posNumber + "</h2>"
                                + "<a href='" + url + "' class='step-link' target='_blank'>"
                                    + "<div class='step-circle'>"
                                        + "<img src='" + image +"'>"
                                    + "</div>"
                                + "</a>"
                                + "<div class='step-txt'>"
                                    + "<h3>" + title + "</h3>"
                                    + "<p>" + description + "</p>"
                                + "</div>"
                            + "</div>";
                    steps.append(row);
                }
            });
        }
    });
});